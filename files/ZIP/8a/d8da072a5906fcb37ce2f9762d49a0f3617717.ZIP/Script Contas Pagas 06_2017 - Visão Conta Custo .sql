select

COD_CONTA_CUSTO,
DS_CONTA_CUSTO,
sum(VL_RAT_PAGCON_PAG) VL_PAGO     --VL_PAGO= R$ 14.652,019,53


from

(
SELECT 
          c.cd_multi_empresa   CD_EMPRESA,
          m.ds_multi_empresa   DS_EMPRESA,
          c.cd_con_pag         CODIGO_MV_CONTAS_PAGAR,
          c.nr_documento,
          c.nr_serie,
          f.cd_fornecedor,
          f.nm_fornecedor, 
          rat.cd_item_res      COD_CONTA_CUSTO, 
          it.ds_item_res       DS_CONTA_CUSTO, 
          CASE WHEN c.cd_caucao IS NULL
            THEN
                Decode ( f.tp_fornecedor,
                    'J' , '#'||LPad(f.NR_CGC_CPF,14,'0'),
                    'F' , '#'||LPad(f.NR_CGC_CPF,11,'0'),
                    f.NR_CGC_CPF
                    )
            ELSE
                (  SELECT '#'CPF_PROPRIETARIO FROM dbamv.caucao WHERE cd_caucao = c.cd_caucao  )

          END nr_cpf_cnpj,
          To_Char(c.dt_emissao, ' dd/mm/yyyy ')dt_emissao,
          To_Char(c.dt_lancamento, ' dd/mm/yyyy ')dt_lancamento,
          To_Char(i.dt_vencimento, ' dd/mm/yyyy ')dt_vencimento,
          To_Char(p.dt_pagamento, 'dd/mm/yyyy')dt_pagamento,
          /*(Nvl (c.vl_bruto_conta,0)    -   Nvl (c.vl_desconto,0)  +   Nvl (c.vl_acrescimo,0)  )*/         

          (Nvl (c.vl_bruto_conta,0)  +
          Nvl (c.vl_desconto,0)   -
          Nvl (c.vl_acrescimo,0)  )vl_bruto_Contas_a_Pagar,

           i.nr_parcela,
           i.vl_duplicata   VL_parcela,

           Nvl (p.vl_desconto,0)vl_desconto_pgto,
           Nvl (p.vl_acrescimo,0)vl_acr�scimo_pgto,
                   
           Nvl (p.vl_pago,0) vl_pago, 
           
           rat.vl_rat_pagcon_pag VL_RAT_PAGCON_PAG,

          To_Char(p.dt_estorno, ' dd/mm/yyyy ')dt_estorno,

          Decode(p.tp_pagamento,
            '1','Border� Boleto',
            '2','Border� DOC',
            '3','Cheque',
            '4','Dinheiro',
            '5','D�bito C/C',
            '6','Presta��o',
            '7','Quita��o Devolu��o',
            '8','TED',
            'E','Encontro de Contas',
            'B','Baixa Cont�bil',
            'Q','Quitado com Desconto',
            p.tp_pagamento)tipo_pagamento,
          Decode(i.tp_quitacao,
            'V','Previsto',
            'C','Comprometido',
            'P','Parcialmente Pago',
            'Q','Quitado',
            'N','Cancelado',
            'T','Liquida��o Total Devolu��o',
            'L','Liquida��o Parcial Devolu��o',
            i.tp_quitacao)status,
          c.cd_reduzido  CD_REDUZIDO, 
          pl.ds_conta    DS_CONTA,
          pr.cd_processo,
          pr.ds_processo

        FROM
          dbamv.processo            pr, 
          dbamv.plano_contas        pl,
          dbamv.fornecedor          f,
          dbamv.con_pag             c,          
          dbamv.itcon_pag           i,
          dbamv.pagcon_pag          p,
          dbamv.multi_empresas      m,
          dbamv.rat_pagcon_pag      rat,
          DBAMV.ITEM_RES            it

        WHERE
          p.dt_pagamento >= to_date('01/06/2017','dd/mm/yyyy')  and
          
          p.dt_pagamento <= to_date('30/06/2017','dd/mm/yyyy')   and
          
                 
          i.cd_itcon_pag        =   p.cd_itcon_pag                      AND
          c.cd_con_pag          =   i.cd_con_pag                        AND
          f.cd_fornecedor  (+)  =   c.cd_fornecedor                     AND
          pl.cd_reduzido   (+)  =   c.cd_reduzido                       AND
          pr.cd_processo   (+)  =   c.cd_processo                       and
          p.cd_pagcon_pag       =   rat.cd_pagcon_pag                   and
          c.cd_multi_empresa    =   m.cd_multi_empresa                  and
          rat.cd_item_res       =   it.cd_item_res                      and
          c.cd_processo    not in (6621,7216)                           and
          p.tp_pagamento   not in ('B',6)
          
          
       )
        
        group by 
            COD_CONTA_CUSTO,
            DS_CONTA_CUSTO
          
        order by 1 asc          